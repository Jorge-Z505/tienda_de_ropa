package tienda.DATOS;

import java.io.*;
import java.util.ArrayList;

import java.util.List;

import tienda.MODELO.Producto;

public class ProductoDt {

    public void guardar(Producto producto) throws Exception {
        if (!producto.esValido()) {
            throw new Exception("Datos inválidos del producto.");
        }

        File archivo = new File("producto.txt");
        if (!archivo.exists()) {
            archivo.createNewFile();
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo, true))) {
            bw.write(producto.getCodigo() + "|" + producto.getNombre() + "|" + producto.getTalla() + "|" +
                     producto.getCategoria() + "|" + producto.getPrecio());
            bw.newLine();
        } catch (IOException e) {
            throw new IOException("Error al escribir en el archivo: " + e.getMessage());
        }
    }

    public void mostrarRecomendaciones(String tallaBuscada) throws IOException {
        File archivo = new File("producto.txt");
        if (!archivo.exists()) {
            System.out.println("No hay productos registrados todavía.");
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            System.out.println("Recomendaciones para talla " + tallaBuscada + ":");
            boolean encontrado = false;

            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split("|");
                if (datos.length == 5) {
                    String talla = datos[2];
                    if (talla.equalsIgnoreCase(tallaBuscada)) {
                        System.out.println("- " + datos[1] + " (" + datos[3] + ") - $" + datos[4]);
                        encontrado = true;
                    }
                }
            }

            if (!encontrado) {
                System.out.println("No hay productos recomendados para esa talla.");
            }
        }
    }
    
    
    
    public class GestorPrendas {
        private static final String ARCHIVO = "producto.txt";
        private static ArrayList<Producto> carrito = new ArrayList<>();

        public static void guardarPrenda(Producto prenda) throws IOException {
            FileWriter fw = new FileWriter(ARCHIVO, true);
            fw.write(prenda.toString() + "\n");
            fw.close();
        }

        public static Producto buscarPorId(String idBuscado) throws IOException {
            BufferedReader br = new BufferedReader(new FileReader(ARCHIVO));
            String linea;
            while ((linea = br.readLine()) != null) {
            	try {
            		Producto p = Producto.fromString(linea);
                    if (p!=null && p.getCodigo().equalsIgnoreCase(idBuscado)) {
                        br.close();
                        return p;
                    }
            	}catch (Exception e) {
            		System.err.println("Linea invalida:" + linea);
            	}
            }
            br.close();
            return null;
        }

        public static void agregarAlCarrito(Producto prenda) {
            carrito.add(prenda);
        }

        public static List<Producto> obtenerCarrito() {
            return carrito;
        }
    }

}
