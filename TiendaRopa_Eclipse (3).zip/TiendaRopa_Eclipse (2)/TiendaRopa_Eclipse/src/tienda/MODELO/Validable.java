package tienda.MODELO;

public interface Validable {
    boolean esValido();
}
