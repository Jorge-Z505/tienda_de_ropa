package tienda.MODELO;

public class Producto implements Validable {
    private String codigo;
    private String nombre;
    private String talla;
    private String categoria;
    private double precio;

    public Producto(String codigo, String nombre, String talla, String categoria, double precio) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.talla = talla;
        this.categoria = categoria;
        this.precio = precio;
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public String getTalla() { return talla; }
    public String getCategoria() { return categoria; }
    public double getPrecio() { return precio; }

    @Override
    public boolean esValido() {
        if (codigo == null || codigo.trim().isEmpty()) return false;
        if (nombre == null || nombre.trim().isEmpty()) return false;
        if (talla == null || talla.trim().isEmpty()) return false;
        if (categoria == null || categoria.trim().isEmpty()) return false;
        if (precio <= 0) return false;
        return true;
    }
    
    @Override
    public String toString() {
        return codigo + "," +nombre + "," + talla + "," + categoria + "," + precio;
    }

    public static Producto fromString(String linea) {
        String[] partes = linea.split(",");
        if (partes.length < 5) {
        	throw new IllegalArgumentException("Linea mal formada: "+ linea);
        }
        double precio = Double.parseDouble(partes[4]);
        return new Producto(partes[0], partes[1], partes[2], partes[3], precio);
    }

}
