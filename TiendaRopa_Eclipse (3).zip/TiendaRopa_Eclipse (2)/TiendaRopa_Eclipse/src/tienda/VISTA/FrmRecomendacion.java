package tienda.VISTA;

import java.io.IOException;
import java.util.List;

import javax.swing.*;
import tienda.LOGICA.ServicioRecomendacion;
import tienda.DATOS.*;
import tienda.DATOS.ProductoDt.GestorPrendas;
import tienda.MODELO.*;

public class FrmRecomendacion extends JFrame {

    private JTextField txtCodigo, txtNombre, txtTalla, txtCategoria, txtPrecio, txtTallaBuscar;
    private JTextArea txtMensajes;
    private JButton btnRegistrar, btnRecomendar;
    private JTextField txtBuscar;

    public FrmRecomendacion() {
        setTitle("Tienda de Ropa - Recomendaciones");
        setSize(764, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        JLabel lblCodigo = new JLabel("Código:");
        lblCodigo.setBounds(20, 20, 100, 25);
        getContentPane().add(lblCodigo);

        txtCodigo = new JTextField();
        txtCodigo.setBounds(130, 20, 200, 25);
        getContentPane().add(txtCodigo);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(20, 60, 100, 25);
        getContentPane().add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(130, 60, 200, 25);
        getContentPane().add(txtNombre);

        JLabel lblTalla = new JLabel("Talla:");
        lblTalla.setBounds(20, 100, 100, 25);
        getContentPane().add(lblTalla);

        txtTalla = new JTextField();
        txtTalla.setBounds(130, 95, 200, 25);
        getContentPane().add(txtTalla);

        JLabel lblCategoria = new JLabel("Categoría:");
        lblCategoria.setBounds(20, 140, 100, 25);
        getContentPane().add(lblCategoria);

        txtCategoria = new JTextField();
        txtCategoria.setBounds(130, 140, 200, 25);
        getContentPane().add(txtCategoria);

        JLabel lblPrecio = new JLabel("Precio:");
        lblPrecio.setBounds(20, 180, 100, 25);
        getContentPane().add(lblPrecio);

        txtPrecio = new JTextField();
        txtPrecio.setBounds(130, 180, 200, 25);
        getContentPane().add(txtPrecio);

        btnRegistrar = new JButton("Registrar Producto");
        btnRegistrar.setBounds(130, 220, 180, 30);
        getContentPane().add(btnRegistrar);

        JLabel lblBuscar = new JLabel("Buscar por talla:");
        lblBuscar.setBounds(20, 260, 100, 25);
        getContentPane().add(lblBuscar);

        txtTallaBuscar = new JTextField();
        txtTallaBuscar.setBounds(130, 260, 100, 25);
        getContentPane().add(txtTallaBuscar);

        btnRecomendar = new JButton("Recomendar");
        btnRecomendar.setBounds(240, 260, 120, 25);
        getContentPane().add(btnRecomendar);

        txtMensajes = new JTextArea();
        txtMensajes.setEditable(false);
        txtMensajes.setBounds(20, 300, 390, 50);
        getContentPane().add(txtMensajes);
        
        txtBuscar = new JTextField();
        txtBuscar.setBounds(523, 63, 176, 18);
        getContentPane().add(txtBuscar);
        txtBuscar.setColumns(10);
        
        
        
        JButton btnAgregar = new JButton("AGREGAR AL CARRITO");
        btnAgregar.setBounds(509, 220, 166, 25);
        btnAgregar.addActionListener(e -> {
            try {
                double precio = Double.parseDouble(txtPrecio.getText());
                Producto p = new Producto(txtCodigo.getText(), txtNombre.getText(), txtTalla.getText(), txtCategoria.getText(), precio);
                GestorPrendas.agregarAlCarrito(p);
                //actualizarCarrito();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Precio inválido.");
            }
        });

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);

        getContentPane().add(btnAgregar);
        
        JLabel lblCoonsultar = new JLabel("Buscar");
        lblCoonsultar.setBounds(469, 66, 44, 12);
        getContentPane().add(lblCoonsultar);
        
        JLabel lblCarrito = new JLabel("CARRITO");
        lblCarrito.setBounds(563, 26, 44, 12);
        getContentPane().add(lblCarrito);
        
        JTextArea txaDatosCarrito = new JTextArea();
        txaDatosCarrito.setBounds(469, 260, 230, 90);
        getContentPane().add(txaDatosCarrito);
        
        JTextArea txaDatosBuscar = new JTextArea();
        txaDatosBuscar.setBounds(469, 128, 230, 50);
        getContentPane().add(txaDatosBuscar);
        
        JButton btnBuscar = new JButton("BUSCAR");
        btnBuscar.setHorizontalAlignment(SwingConstants.LEFT);
        btnBuscar.addActionListener (e -> {
            try {
                Producto p = GestorPrendas.buscarPorId(txtBuscar.getText());
                if (p != null) {
                    txaDatosBuscar.setText("ID: " + p.getCodigo() +
                                         "\nNombre: " + p.getNombre() +
                                         "\nTalla: " + p.getTalla() +
                                         "\nCategoria: " + p.getCategoria() +
                                         "\nPrecio: Bs " + String.format("%.2f", p.getPrecio()));
                } else {
                    txaDatosBuscar.setText("Producto no encontrado.");
                }
            } catch (IOException ex) {
                txaDatosBuscar.setText("Error al consultar.");
            }
        });

        btnBuscar.setBounds(544, 97, 71, 20);
        getContentPane().add(btnBuscar);
        btnRegistrar.addActionListener(e -> registrarProducto());
        btnRecomendar.addActionListener(e -> recomendar());
    }

    private void registrarProducto() {
        txtMensajes.setText("");
        try {
            String codigo = txtCodigo.getText();
            String nombre = txtNombre.getText();
            String talla = txtTalla.getText();
            String categoria = txtCategoria.getText();
            double precio = Double.parseDouble(txtPrecio.getText());

            ServicioRecomendacion servicio = new ServicioRecomendacion();
            servicio.registrarProducto(codigo, nombre, talla, categoria, precio);
            txtMensajes.setText("✅ Producto registrado correctamente.");
        } catch (NumberFormatException ex) {
            txtMensajes.setText("⚠️ Error: el precio debe ser numérico.");
        } catch (Exception ex) {
            txtMensajes.setText("⚠️ " + ex.getMessage());
        }
    }

    private void recomendar() {
        txtMensajes.setText("");
        String talla = txtTallaBuscar.getText();
        try {
            ServicioRecomendacion servicio = new ServicioRecomendacion();
            servicio.recomendarPorTalla(talla);
        } catch (Exception ex) {
            txtMensajes.setText("⚠️ " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new FrmRecomendacion().setVisible(true);
    }
    
    
    /*private void actualizarCarrito() {
    	txaDatosCarrito.setText("");
        List<Producto> carrito = GestorPrendas.obtenerCarrito();
        txaDatosCarrito.setText("");
        for (Producto p : carrito) {
            txaDatosCarrito.append(p.toString() + "\n");
        }
        List<Producto> total = GestorPrendas.obtenerCarrito();
        areaCarrito.append("\nTOTAL: Bs " + String.format("%.2f", total));
    }*/

    
}
