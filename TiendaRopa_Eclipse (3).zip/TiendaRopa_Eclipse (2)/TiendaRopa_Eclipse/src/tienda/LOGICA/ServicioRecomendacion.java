package tienda.LOGICA;

import tienda.MODELO.Producto;
import tienda.DATOS.ProductoDt;

public class ServicioRecomendacion {

    public void registrarProducto(String codigo, String nombre, String talla, String categoria, double precio) throws Exception {
        Producto producto = new Producto(codigo, nombre, talla, categoria, precio);
        ProductoDt dao = new ProductoDt();
        dao.guardar(producto);
    }

    public void recomendarPorTalla(String talla) throws Exception {
        ProductoDt dao = new ProductoDt();
        dao.mostrarRecomendaciones(talla);
    }
}
